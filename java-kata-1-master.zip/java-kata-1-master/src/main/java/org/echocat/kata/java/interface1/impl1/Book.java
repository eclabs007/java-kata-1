package org.echocat.kata.java.interface1.impl1;

import org.echocat.kata.java.Author;
import org.echocat.kata.java.interface1.Publication;

import java.util.ArrayList;
import java.util.List;

public class Book implements Publication {

    private String title;
    private List<Author> authors;
    private String isbn;
    private String isBookOrMagazine;
    private String description;

    @Override
    public String getTitle() {
        return title != null ? title : "No Title";
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public List<Author> getAuthors() {
        return authors != null ? authors : new ArrayList<>();
    }

    public void setAuthors(List<Author> authors) {
        this.authors = authors;
    }

    @Override
    public String getIsbn() {
        return isbn != null ? isbn : "No ISBN";
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    @Override
    public String getIsBookOrMagazine() {
        return isBookOrMagazine != null ? isBookOrMagazine : "Undecided";
    }

    public void setIsBookOrMagazine(String isBookOrMagazine) {
        this.isBookOrMagazine = isBookOrMagazine;
    }

    public String getDescription() {
        return description != null ? description : "No Description";
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Book{" +
                "title='" + title + '\'' +
                ", authors=" + authors +
                ", isbn='" + isbn + '\'' +
                ", isBookOrMagazine='" + isBookOrMagazine + '\'' +
                ", description='" + description + '\'' +
                '}';
    }

}
