package org.echocat.kata.java.interface1.impl1;

import org.echocat.kata.java.Author;
import org.echocat.kata.java.interface1.Publication;

import java.util.ArrayList;
import java.util.List;

public class Magazine implements Publication {

    private String title;
    private List<Author> authors;
    private String isbn;
    private String isBookOrMagazine;
    private String publishedAt;

    @Override
    public String getTitle() {
        return title != null ? title : "No Title";
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public List<Author> getAuthors() {
        return authors != null ? authors : new ArrayList<>();
    }

    public void setAuthors(List<Author> authors) {
        this.authors = authors;
    }

    @Override
    public String getIsbn() {
        return isbn != null ? isbn : "No ISBN";
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    @Override
    public String getIsBookOrMagazine() {
        return isBookOrMagazine != null ? isBookOrMagazine : "Undecided";
    }

    public void setIsBookOrMagazine(String isBookOrMagazine) {
        this.isBookOrMagazine = isBookOrMagazine;
    }

    public String getPublishedAt() {
        return publishedAt != null ? publishedAt : "No date";
    }

    public void setPublishedAt(String publishedAt) {
        this.publishedAt = publishedAt;
    }

    @Override
    public String toString() {
        return "Magazine{" +
                "title='" + title + '\'' +
                ", publishedAt=" + publishedAt +
                ", authors=" + authors +
                ", isbn='" + isbn + '\'' +
                ", isBookOrMagazine='" + isBookOrMagazine + '\'' +
                '}';
    }

}
