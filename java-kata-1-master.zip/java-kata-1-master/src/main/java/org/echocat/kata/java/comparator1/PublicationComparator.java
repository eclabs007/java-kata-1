package org.echocat.kata.java.comparator1;

import org.echocat.kata.java.interface1.Publication;

import java.util.Comparator;

public class PublicationComparator implements Comparator<Publication> {

    @Override
    public int compare(Publication publication1, Publication publication2) {
        return publication1.getTitle().compareTo(publication2.getTitle());
    }

}
