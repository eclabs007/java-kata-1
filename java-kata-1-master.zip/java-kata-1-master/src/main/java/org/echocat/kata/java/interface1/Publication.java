package org.echocat.kata.java.interface1;

import org.echocat.kata.java.Author;

import java.util.List;

public interface Publication {

    String getTitle();

    List<Author> getAuthors();

    String getIsbn();

    String getIsBookOrMagazine();

}