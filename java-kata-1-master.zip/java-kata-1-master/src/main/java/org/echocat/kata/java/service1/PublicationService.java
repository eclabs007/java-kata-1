package org.echocat.kata.java.service1;

import org.echocat.kata.java.Author;
import org.echocat.kata.java.interface1.Publication;

import java.util.List;

public interface PublicationService {

    List<Author> readAuthorsFromCsv(String fileName);

    List<Publication> readBooksFromCsv(String fileName, List<Author>authorList);

    List<Publication> readMagazinesFromCsv(String fileName, List<Author>authorList);

    List<Publication> getPublicationsWithIsbn(String isbn, List<Publication>publicationList);

    List<Publication> getPublicationsWithAuthor(String author, List<Publication>publicationList);

}
