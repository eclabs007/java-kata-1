package org.echocat.kata.java.part1;
import java.util.List;

import org.echocat.kata.java.Author;
import org.echocat.kata.java.interface1.Publication;
import org.echocat.kata.java.service1.PublicationService;
import org.echocat.kata.java.service1.PublicationServiceImpl;

public class MainApp {

	public static void main(String[] args) {
		System.out.println(getHelloWorldText());
		PublicationService publicationService = new PublicationServiceImpl();
		//should ignore first records
		List<Author> authors = publicationService.readAuthorsFromCsv(System.getProperty("user.dir")
				+ "\\src\\main\\resources\\org\\echocat\\kata\\java\\part1\\data\\authors.csv");
		List<Publication> publications = publicationService.readBooksFromCsv(System.getProperty("user.dir")
				+ "\\src\\main\\resources\\org\\echocat\\kata\\java\\part1\\data\\books.csv", authors);
		publications.addAll(publicationService.readMagazinesFromCsv(System.getProperty("user.dir")
				+ "\\src\\main\\resources\\org\\echocat\\kata\\java\\part1\\data\\magazines.csv", authors));	
		
		System.out.println(authors);			
		System.out.println(publications);		
		System.out.println(publicationService.getPublicationsWithIsbn("4545-8558-3232", publications));
		System.out.println(publicationService.getPublicationsWithAuthor("null-gustafsson@echocat.org", publications));
		
		
	}

	protected static String getHelloWorldText() {
		// PublicationService publicationService = new PublicationServiceImpl();
		return "Hello world!";
	}

}
