package org.echocat.kata.java.service1;

import org.echocat.kata.java.Author;
import org.echocat.kata.java.interface1.Publication;
import org.echocat.kata.java.interface1.impl1.Book;
import org.echocat.kata.java.interface1.impl1.Magazine;

import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PublicationServiceImpl implements PublicationService {

	@Override
	public List<Author> readAuthorsFromCsv(String fileName) {
		CSVReader csvReader = null;
		try {

			FileReader filereader = new FileReader(fileName);
			CSVParser parser = new CSVParserBuilder().withSeparator(';').build();
			csvReader = new CSVReaderBuilder(filereader).withCSVParser(parser).withSkipLines(1).build();
			String[] nextRecord;
			List<Author> authorList = new ArrayList<Author>();
			while ((nextRecord = csvReader.readNext()) != null) {
				// for (String cell : nextRecord) {
				// create author details
				Author author = new Author();
				author.setEmail(nextRecord[0].trim());
				author.setFirstName(nextRecord[1].trim());
				author.setLastName(nextRecord[2].trim());
				authorList.add(author);
				// }
			}
			return authorList;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (csvReader != null)
					csvReader.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return new ArrayList<Author>();

	}

	@Override
	public List<Publication> readBooksFromCsv(String fileName, List<Author> authorList) {
		CSVReader csvReader = null;
		try {

			FileReader filereader = new FileReader(fileName);
			CSVParser parser = new CSVParserBuilder().withSeparator(';').build();
			csvReader = new CSVReaderBuilder(filereader).withCSVParser(parser).withSkipLines(1).build();
			String[] nextRecord;
			List<Publication> bookList = new ArrayList<Publication>();
			while ((nextRecord = csvReader.readNext()) != null) {
				// for (String cell : nextRecord) {
				// create author details
				Book book = new Book();
				book.setTitle(nextRecord[0].trim());
				book.setIsbn(nextRecord[1].trim());
				List<String> authors = Arrays.asList(nextRecord[2].trim().split(","));
				List<Author> tempAuthors = new ArrayList<Author>();
				for (Author author : authorList) {
					if (authors.contains(author.getEmail())) {
						tempAuthors.add(author);
					}
				}
				book.setAuthors(tempAuthors);
				book.setDescription(nextRecord[3].trim());
				book.setIsBookOrMagazine("Book");
				bookList.add(book);
				// }
			}
			return bookList;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (csvReader != null)
					csvReader.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return new ArrayList<Publication>();
	}

	@Override
	public List<Publication> readMagazinesFromCsv(String fileName, List<Author>authorList) {
		CSVReader csvReader = null;
		try {

			FileReader filereader = new FileReader(fileName);
			CSVParser parser = new CSVParserBuilder().withSeparator(';').build();
			csvReader = new CSVReaderBuilder(filereader).withCSVParser(parser).withSkipLines(1).build();
			String[] nextRecord;
			List<Publication> magazineList = new ArrayList<Publication>();
			while ((nextRecord = csvReader.readNext()) != null) {
				// for (String cell : nextRecord) {
				// create author details
				Magazine magazine = new Magazine();
				magazine.setTitle(nextRecord[0].trim());
				magazine.setIsbn(nextRecord[1].trim());
				List<String> authors = Arrays.asList(nextRecord[2].trim().split(","));
				List<Author> tempAuthors = new ArrayList<Author>();
				for (Author author : authorList) {
					if (authors.contains(author.getEmail())) {
						tempAuthors.add(author);
					}
				}
				magazine.setAuthors(tempAuthors);
				magazine.setPublishedAt(nextRecord[3].trim());
				magazine.setIsBookOrMagazine("Magazine");
				magazineList.add(magazine);
				// }
			}
			return magazineList;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (csvReader != null)
					csvReader.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return new ArrayList<Publication>();
	}

	@Override
	public List<Publication> getPublicationsWithIsbn(String isbn, List<Publication>publicationList) {

		List<Publication>searchHitPublicationList = new ArrayList<Publication>();
		for (Publication publication : publicationList) {
			if(publication.getIsbn().equals(isbn)) {
				searchHitPublicationList.add(publication);
			}
		}		
		return searchHitPublicationList;
	}

	@Override
	public List<Publication> getPublicationsWithAuthor(String authorEmail, List<Publication>publicationList) {
		List<Publication>searchHitPublicationList = new ArrayList<Publication>();
		for (Publication publication : publicationList) {
			List<Author> associatedAuthorList = publication.getAuthors();
			for (Author associatedAuthor : associatedAuthorList) {
				if(associatedAuthor.getEmail().equals(authorEmail)) {
					searchHitPublicationList.add(publication);
				}
			}
		}		
		return searchHitPublicationList;
	}

}
